# Hackathon2023
HUJI Hackathon 2023


Next versions:
Character appearance variabilities
Player appearance variabilities
multiple characters in room / Rooms withot characters
Room decorations
Dalle textures
In game objectives
Transitions in center (not on boundaries)